function increaseVal(id) {
  let val = document.getElementById(`input${id}`);
  let number = parseInt(val.value, 10);

  number += 1;
  val.value = number;
}

function decreaseVal(id) {
  let val = document.getElementById(`input${id}`);
  let number = parseInt(val.value, 10);
  if (number - 1 < 0) return;

  number -= 1;
  val.value = number;
}

const increaseValue = Array.from(document.getElementsByClassName('increase'));
const decreaseValue = Array.from(document.getElementsByClassName('decrease'));

for (let i = 0; i <= 5; i++) {
  increaseValue[i].addEventListener('click', () => {
    increaseVal(i + 1);
  });
}

for (let i = 0; i <= 5; i++) {
  decreaseValue[i].addEventListener('click', () => {
    decreaseVal(i + 1);
  });
}

function refreshPage() {
  location.reload();
}

